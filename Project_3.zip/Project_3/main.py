#!/usr/bin/env python

# 2022 Dongji Gao
# 2022 Yiwen Shao

from fileinput import filename
import os
import sys
import string
import torch
from torch.utils.data import Dataset, DataLoader
import torch.optim as optim
from torch import nn
from torch.nn.utils.rnn import pad_sequence
from dataset import *
from model import *
from pdb import set_trace as bp
import numpy as np
import tqdm
from itertools import groupby
import random
import sys
import pickle
random.seed(786)
torch.manual_seed(786)
np.random.seed(786)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def count_parameters(model):
    """
    This function given the model will count the total paramter
    input args: model to train
    return args: count of number of parameter of the model
    """
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def collate_fn(batch):
    """
    This function will be passed to your dataloader.
    It pads word_spelling (and features) in the same batch to have equal length.with 0.
    :param batch: batch of input samples
    :return: (recommended) padded_word_spellings, 
                           padded_features,
                           list_of_unpadded_word_spelling_length (for CTCLoss),
                           list_of_unpadded_feature_length (for CTCLoss)
    """
    # === write your code here ===
    # batch[1][0] -> target label, batch[1][1] -> feature
    target_label = [x[0] for x in batch] # iterate through batch to obtain the target label
    feature_matrix = [x[1] for x in batch] # iterate through batch to obtain the feature matrix
    list_of_unpadded_word_spelling_length = [(x).shape[0] for x in target_label] # get the length of target label without any padding
    list_of_unpadded_feature_length = [(x).shape[0] for x in feature_matrix] # get the length of feature matrix without any padding
    padded_word_spellings = pad_sequence(target_label, batch_first=True, padding_value=0) # pad the label matrix in same batch
    padded_features = pad_sequence(feature_matrix, batch_first=True, padding_value=0) # pad the feature matrix in the same batch

    return padded_word_spellings, padded_features, list_of_unpadded_word_spelling_length,list_of_unpadded_feature_length

def train(train_dataloader,model, ctc_loss, optimizer):
    """
    This function will be used to train the model
    Input args:
    model -> model that needs to be trained
    train_dataloader -> training dataloader -> pytorch
    ctc_loss -> our loss criteria -> format ctc_loss(your_pred_tensor, true_target_label, feature_len_without_pad, target_len_without_pad)
    optimizer -> optimizer -> my case: Adam
    :return: avg_train_loss -> average training loss for that epoch
    """
    # === train block ===
    model.train() # set for training
    total_loss = 0 # set your training loss to be zero !
    for i,data  in enumerate(train_dataloader): 
        optimizer.zero_grad() # set the weights of optimizer
        y_true = data[0].to(device) # input label  -> tensor [batch x time]
        x_train = data[1].to(device) # input training data -> torch tensor [batch x time x feature]
        target_len = data[2] # target unpadded len -> list -> len(list) = batch_size
        feature_len = data[3] # telling unpadded feature len -> list -> len(list) = batch_size
        y_pred = model(x_train) # pass it through the model
        y_pred = y_pred.permute(1,0,2) # for ctc loss converting it in proper format from [batch x time x feature] -> [Time x batch x feature]
        loss = ctc_loss(y_pred, y_true, feature_len, target_len) # conpute the ctc loss
        loss.backward() # do loss backward
        optimizer.step() # update the weights
        total_loss += loss.item()
    avg_train_loss = total_loss/len(train_dataloader) # cal avg training loss
    return avg_train_loss

def eval(val_dataloader,model, ctc_loss):
    """
    This function will be used to evaluate the model, if overfitting or not
    Input args:
    model -> model that needs to be evaluated
    val_dataloader -> validation dataloader -> pytorch
    ctc_loss -> our loss criteria -> format ctc_loss(your_pred_tensor, true_target_label, feature_len_without_pad, target_len_without_pad)
    :return: avg_val_loss -> average validation loss for that epoch
    """
    model.eval()
    val_loss = 0
    for i,data  in enumerate(val_dataloader):
        y_true = data[0].to(device) # input label  -> tensor [batch x time]
        x_train = data[1].to(device) # input training data -> torch tensor [batch x time x feature]
        target_len = data[2] # target unpadded len -> list
        feature_len = data[3] # telling unpadded feature len -> list
        y_pred = model(x_train) # pass it through the model
        v_loss = ctc_loss(y_pred.permute(1,0,2), y_true, feature_len, target_len) # conpute the ctc loss
        val_loss += v_loss.item() # add the validation loss
    avg_val_loss = val_loss/len(val_dataloader) # cal avg val loss
    return avg_val_loss


def decode_greedy(model, deco_train_loader,id2letter):
    """
    This code implement the greedy decoding
    Algo for greedy decoding
    1. Replace all contiguous repetitions of a letter (including β) with a single instance of the letter (resp. β)
    2. Delete all instances of β.

    Input Args:
    model: model used to get the predcitions
    deco_train_loader: held out set, not used for training, to get the predictions
    id2letter: type {} -> id_every_letter:letter
    returns: 
    prediction_dictionary-: a dictionary that will give pred word and true word
    """
    model.eval()
    prediction_dictionary = {} # dictionary to store the results
    for i,data in enumerate(deco_train_loader):
        y_true = data[0].to(device) # input label  -> tensor [batch x time]
        x_train = data[1].to(device) # input training data -> torch tensor [batch x time x feature]
        y_pred = model(x_train) # pass through model
        _, max_index = torch.max(y_pred, dim=2)  # max_index.shape == torch.Size([32, 64])
        max_index = max_index.squeeze(dim=0) 
        max_index = torch.unique_consecutive(max_index) # to remove the repeating words
        y_true = y_true.squeeze(dim=0) 
        pred_vec = [max_index[x].item() for x in range(len(max_index)) if max_index[x] > 1] # get your predicted word, by replacing <sil> and <blank>
        true_vec = [y_true[x].item() for x in range(len(y_true)) if y_true[x].item() > 1] #in your true word remove the <sil>
        pred_word = ''.join([id2letter[x] for x in pred_vec]) # get the pred word
        true_word = ''.join([id2letter[x] for x in true_vec]) # get the true word
        prediction_dictionary[i] = {'true_label': true_word,'pred_word': pred_word} # store them in some dictionary    
    return prediction_dictionary

def convert_vocab(vocab, id2letter):
    """
    This code convert every letter into a number s.t it can be used in the ctc loss
    input args:
    vocab: vocabulary words
    id2letter: type {} -> id_every_letter:letter
    """
    letter2id = {value:key for key,value in id2letter.items()} # letter:id
    vocab2check = {} # for every word creat the list of index
    for word in vocab:
        temp_list = [letter2id[x] for x in word] # convert each letter into corresponding id
        temp_list.insert(0,1) # add <sil> in starting and ending
        temp_list.append(1)
        vocab2check[word] = (temp_list) # {'cat':[3,1,23]}
    return vocab2check
    
def decode_CTC(model, deco_train_loader, ctc_loss, id2letter, vocab):
    """
    To implement the CTC Based decoding
    Algo
    1. Pass the feature vector through the model, and get the pred vector
    2. now for all word in your vocabulary, compute the ctc loss with each word
    3. predict that word which gives you the lowest ctc loss

    Input Args:
    model: model used to get the predcitions
    deco_train_loader: held out set, not used for training, to get the predictions
    ctc_loss: ctc loss to cal loss
    id2letter: type {} -> id_every_letter:letter
    vocab: unique words in your vocabulary

    returns: 
    prediction_dictionary-: a dictionary that will give pred word and true word
    """
    model.eval()
    # define the loss criterion
    loss_function = ctc_loss
    prediction_dictionary ={} # a dictionary to store the results
    vocab2check = convert_vocab(vocab, id2letter) # this function will convert vocabulary in proper format

    for i,data in enumerate(deco_train_loader):
        y_true = data[0].to(device) # input label  -> tensor [batch x time]
        x_train = data[1].to(device) # input training data -> torch tensor [batch x time x feature]
        feature_len = data[3] # telling unpadded feature len -> list
        y_pred = model(x_train) # get the prediction
        pred_results = {} # a dictionary to store given the word what will be the loss
        for word,label in vocab2check.items():
            label = torch.IntTensor(label) # convert label to torch tensor
            loss = loss_function(y_pred.permute(1,0,2), label.unsqueeze(0), feature_len,[label.size()[0]]) # compute the loss
            pred_results[word] = loss.item() # save the predicted results
        pred_word = min(pred_results, key=pred_results.get) # get the word with min loss
        y_true = y_true.squeeze(dim=0)
        true_vec = [y_true[x].item() for x in range(len(y_true)) if y_true[x].item() > 1] 
        true_word = ''.join([id2letter[x] for x in true_vec]) # get the true word
        prediction_dictionary[i] = {'true_label': true_word,'pred_word': pred_word} # store them in some dictionary
        
    return prediction_dictionary

def test_decode_CTC(model, loss_function, test_dataloader, id2letter, vocab):
    """
    To predict the decoding word for test dataset
    Algo
    1. Pass the feature vector through the model, and get the pred vector
    2. now for all word in your vocabulary, compute the ctc loss with each word
    3. predict that word which gives you the lowest ctc loss

    Input Args:
    model: model used to get the predcitions
    deco_train_loader: held out set, not used for training, to get the predictions
    ctc_loss: ctc loss to cal loss
    id2letter: type {} -> id_every_letter:letter
    vocab: unique words in your vocabulary
    """
    model.eval()
    prediction_dictionary = {} # store word + confidence score
    vocab2check = convert_vocab(vocab, id2letter) # this function will convert vocabulary in proper format

    for i,data in enumerate(test_dataloader):
        y_true = data[0].to(device) # input label  -> tensor [batch x time]
        x_train = data[1].to(device) # input training data -> torch tensor [batch x time x feature]
        feature_len = data[3] # telling unpadded feature len -> list
        y_pred = model(x_train) # get the prediction
        pred_results = {} # a dictionary to store given the word what will be the loss
        for word,label in vocab2check.items():
            label = torch.IntTensor(label) # convert label to torch tensor
            loss = loss_function(y_pred.permute(1,0,2), label.unsqueeze(0), feature_len,[label.size()[0]]) # compute the loss
            pred_results[word] = loss.item() # save the predicted results
        pred_word = min(pred_results, key=pred_results.get) # get the word with min lossn
        prob_value = np.exp(-1*pred_results[pred_word]) # get the prob value
        prediction_dictionary[i] = {'pred_word': pred_word, 'prob_value': prob_value}
    return prediction_dictionary

def compute_accuracy(prediction_dictionary):
    """
    fucntion compute the accuracy on val split
    input args: prediction_dictionary -> contain the true and corrected word
    return : accuracy of the model
    """
    total_data = 0
    total_correct_count = 0
    for value in prediction_dictionary.values():
        total_data += 1
        pred_word = value['pred_word'] # get the predicted word
        correct_word = value['true_label'] # get the true word
        if pred_word == correct_word: 
            total_correct_count += 1 
    accuracy = total_correct_count/total_data # cal accuracy
    return accuracy

def Confidence_Score(experiment_dic,filename='Confidence_Score.txt'):
    
    file = open(filename, "w") # define+open the filename
    for index in experiment_dic['prediction_dictionary_test'].keys():
        word = experiment_dic['prediction_dictionary_test'][index]['pred_word'] # write the prediction
        score = experiment_dic['prediction_dictionary_test'][index]['prob_value'] # write the confidence score
        file.write(str(word) + " " + str(score) + "\n")
    file.close()
    

def main():
    # === Define the training and test set === #
    training_set = {"scr_file": sys.argv[2], "feature_type": sys.argv[1], "feature_file": sys.argv[3], 
    "feature_label_file": sys.argv[4], "wav_scp": sys.argv[5], "wav_dir": sys.argv[6]} # dictionary that will store the relevant things for train data

    test_set = {"scr_file": sys.argv[2], "feature_type": sys.argv[1], "feature_file": sys.argv[7], 
    "feature_label_file": sys.argv[4], "wav_scp": sys.argv[8], "wav_dir": sys.argv[6]} # dictionary, test data relevant information

    # === Define the train,val and test dataloaders === #
    train_dataset = AsrDataset(scr_file=training_set["scr_file"], feature_type=training_set["feature_type"],
    feature_file=training_set["feature_file"], feature_label_file=training_set['feature_label_file'], 
    wav_scp=training_set['wav_scp'], wav_dir=training_set['wav_dir']) # define the train dataloader

    # define the train and validation dataloader
    train_set = AsrDataset(scr_file='data/clsp.trnscr_kept.scp', feature_type=training_set["feature_type"],
    feature_file='data/clsp.trnlbls_kept.scp', feature_label_file=training_set['feature_label_file'], 
    wav_scp='data/clsp.trnwav_kept.scp', wav_dir=training_set['wav_dir']) # define the train dataloader

    val_set = AsrDataset(scr_file='data/clsp.trnscr_held.scp', feature_type=training_set["feature_type"],
    feature_file='data/clsp.trnlbls_held.scp', feature_label_file=training_set['feature_label_file'], 
    wav_scp='data/clsp.trnwav_held.scp', wav_dir=training_set['wav_dir']) # define the train dataloader

    train_dataloader = DataLoader(dataset=train_set, batch_size=32,shuffle=True,collate_fn=collate_fn) #dataloader for train
    val_dataloader = DataLoader(dataset=val_set, batch_size=32,shuffle=True,collate_fn=collate_fn) #dataloader for val
    
    deco_train_loader_all_train = DataLoader(dataset=train_dataset, batch_size=1,shuffle=False,collate_fn=collate_fn) #dataloader for val
    deco_train_loader = DataLoader(dataset=val_set, batch_size=1,shuffle=False,collate_fn=collate_fn) #dataloader for val
    
    # define the test dataloader
    test_dataset = AsrDataset(scr_file=test_set["scr_file"], feature_type=test_set["feature_type"],
    feature_file=test_set["feature_file"], feature_label_file=test_set['feature_label_file'],  # define the test dataloader condition
    wav_scp=test_set['wav_scp'], wav_dir=test_set['wav_dir'])
    test_dataloader = DataLoader(dataset=test_dataset, batch_size=1,shuffle=False,collate_fn=collate_fn) #dataloader for test

    # === Define the model and loss function === #
    # define parameters
    feature_type = sys.argv[1] # disceret, mfcc, plp
    if feature_type=='discrete':
        input_size = 64
    if feature_type=='mfcc':
        input_size = 13
    if feature_type=='rasta':
        input_size = 64 
    if feature_type=='mfcc_delta':
        input_size = 39
    hidden_size = 256 # hidden dimension size of lstm
    num_layers = 2 # num of layers of lstm
    output_size = 28 # output size of your model
    drop_prob = 0.5 # dropout prob
    bi_direct = True # if you want lstm or blstm
    model = LSTM_ASR(feature_type= feature_type, input_size= input_size, hidden_size= hidden_size, 
    num_layers = num_layers, output_size= output_size, drop_prob= drop_prob,bi_direct = bi_direct)
    model.to(device) # model to train 

    print('num of model parameters: ',count_parameters(model))

    # define the loss
    loss_function = torch.nn.CTCLoss() # have to make this one specific

    optimizer = torch.optim.Adam(model.parameters(), lr=5e-4)
    
    # creating the word to id dictionary 
    letter2id = train_dataset.letter2id # letter2id dictionary
    id2letter = train_dataset.id2letter # id2letter dictionary
    # get the vocabulary
    trnscr = read_file_line_by_line(os.path.join('data/', 'clsp.trnscr')) # get the training data
    vocab = list(set(trnscr)) # get the unique word out of the training data

    # Training
    num_epochs =  int(sys.argv[9])
    patience = int(sys.argv[10])
    training_loss_list = []
    val_loss_list = []
    prev_val_loss = 1e6
    for epoch in range(num_epochs):
        training_loss = train(train_dataloader,model, loss_function, optimizer) # train  
        val_loss = eval(val_dataloader,model, loss_function) # val
        training_loss_list.append(training_loss) # append the training loss
        val_loss_list.append(val_loss) # append val loss

        if val_loss < prev_val_loss:
            torch.save(model.state_dict(), sys.argv[1]+'_model.pt') # save the best model
            prev_val_loss = val_loss # set the prev val loss
        print('Epoch: {} \tTraining Loss: {:.8f} \tValidation Loss {:.8f}'.format(epoch + 1, training_loss,val_loss))

    # Testing (totally by yourself)
    # load the best model
    model.load_state_dict(torch.load(sys.argv[1]+'_model.pt'))

    prediction_dictionary_greedy = decode_greedy(model, deco_train_loader,id2letter) # do the greedy deconding
    perf_greedy = compute_accuracy(prediction_dictionary_greedy) # compute the accuracy of greedy decoding
    print('Greedy Decoding accuracy = ', perf_greedy) 

    prediction_dictionary_CTC = decode_CTC(model, deco_train_loader, loss_function, id2letter, vocab) # do the CTC decoding
    perf_CTC = compute_accuracy(prediction_dictionary_CTC) # compute the accuracy of greedy decoding
    print('CTC Decoding accuracy = ', perf_CTC) 

    prediction_dictionary_CTC_all_train = decode_CTC(model, deco_train_loader_all_train, loss_function, id2letter, vocab) # do the CTC decoding
    perf_CTC_all = compute_accuracy(prediction_dictionary_CTC_all_train) # compute the accuracy of greedy decoding
    print('CTC Decoding accuracy on all train data = ', perf_CTC_all) 

    # this will store the details of the experiments
    prediction_dictionary_test = test_decode_CTC(model, loss_function, test_dataloader, id2letter, vocab)

    # storing the results dictionry
    experiment_dic = {'train_loss': training_loss_list, 'val_loss': val_loss_list, 'prediction_dictionary_greedy': prediction_dictionary_greedy,
    'perf_greedy': perf_greedy, 'prediction_dictionary_CTC': prediction_dictionary_CTC,'perf_CTC': perf_CTC,
    'prediction_dictionary_test': prediction_dictionary_test,'prediction_dictionary_CTC_all_train':prediction_dictionary_CTC_all_train,'perf_CTC_all':perf_CTC_all }

    print('Calculating the confidence and prediction')
    filename = 'Confidence_Score/'+'Confidence_Score_'+sys.argv[1]+'.txt'
    Confidence_Score(experiment_dic,filename)

    a_file = open("experiments_summary.pkl", "wb") # store the experiments results
    pickle.dump(experiment_dic, a_file)
    a_file.close()

if __name__ == "__main__":
    main()
