Information Extraction Project 3
By: Rohit K (rkumar44@jh.edu)
Date: 12th May, 2022

Information_Extraction_Project_3: report for the project 

[NOTE]
FOR RASTA-PLP in need one additionally libraray 'spectrum' hence before running do this

conda install -c conda-forge spectrum

[CODES]

1. main.py: main code for the project 3 i.e implementation of e2e ctc based asr. Contain the train, validation block and decoding block.

2. dataset.py: Pytorch Dataloader for our experiment.

3. model.py: Contain the LSTM Based PYTORCH based model.

4. run_primary_discrete.sh: Run this bash to obtain the e2e ctc based asr with discrete features. In the bash file you can change the features and number of iterations for your implementation.
    Usage: " bash run_primary_discrete.sh "

5. run_mfcc.sh: Run this bash to obtain the e2e ctc based asr with mfcc 13 dim features. In the bash file you can change the features and number of iterations for your implementation.
    Usage: " bash run_mfcc.sh "

6. run_mfcc_delta.sh: Run this bash to obtain the e2e ctc based asr with 13 dim mfcc + 13 dim delta + 13 dim double delta features. In the bash file you can change the features and number of iterations for your implementation.
    Usage: " bash run_mfcc_delta.sh "

7. run_rasta.sh: Run this bash to obtain the e2e ctc based asr with plp-rasta features. In the bash file you can change the features and number of iterations for your implementation.
    Usage: " bash run_rasta.sh "

8. rasta.py: code used to extract rasta-plp feautures. 

[FOLDERS/FILES]

1. Confidence_Score: Folder contain the prediction+confidence score for different systems used.
    1.1. Confidence_Score_Discrete.txt : Prediction+Confidence for the primary system.

    1.2. Confidence_Score_MFCC_40.txt: Prediction+Confidence for the MFCC 40(default given by TA).
    
    1.3. Confidence_Score_MFCC_13.txt : Prediction+Confidence for the MFCC 13.
    
    1.4. Confidence_Score_MFCC_DELTA.txt : Prediction+Confidence for the MFCC 13+ MFCC Delta + MFCC Double Delta.
    
    1.5. Confidence_Score_RASTA.txt: Prediction+Confidence for the PLP-RASTA Features of order 8.

2. data: contain the data, required in the experiments. Contain wav.scp+audio files.



