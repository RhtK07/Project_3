from unicodedata import bidirectional
import torch
from pdb import set_trace as bp
import torch.nn.functional as F
import random
import numpy as np
random.seed(786)
torch.manual_seed(786)
np.random.seed(786)

class LSTM_ASR(torch.nn.Module):
    def __init__(self, feature_type="discrete", input_size=64, hidden_size=256, num_layers=2,output_size=28,drop_prob=0.5,bi_direct=True):
        super(LSTM_ASR,self).__init__()
        assert feature_type in ['discrete', 'mfcc','rasta','mfcc_delta']
        self.feature_type = feature_type
        if self.feature_type =='discrete':
            self.embedding_layer = torch.nn.Embedding(257, input_size, padding_idx=0) # embedding dimension
            self.lstm = torch.nn.LSTM(input_size=input_size,hidden_size=hidden_size
            ,num_layers=num_layers,bidirectional=bi_direct,batch_first=True) # batch_first true -> as my input is batch x sequence x feats_size
            self.dropout = torch.nn.Dropout(drop_prob) # define the dropout prob
            if bi_direct:
                self.final_layer = torch.nn.Linear(hidden_size*2,out_features=output_size) # final layer projection for bilstm as it require 2*hidden size
            else:
                self.final_layer = torch.nn.Linear(hidden_size,out_features=output_size) # final layer for lstm
            self.log_softmax = torch.nn.LogSoftmax(dim=2) 

        if self.feature_type == 'mfcc' or self.feature_type == 'mfcc_delta':
            self.lstm = torch.nn.LSTM(input_size=input_size,hidden_size=hidden_size
            ,num_layers=num_layers,bidirectional=bi_direct,dropout=drop_prob,batch_first=True) # batch_first true -> as my input is batch x sequence x feats_size
            self.dropout = torch.nn.Dropout(drop_prob) # define the dropout prob
            if bi_direct:
                self.final_layer = torch.nn.Linear(hidden_size*2,out_features=output_size) # final layer projection for bilstm as it require 2*hidden size
            else:
                self.final_layer = torch.nn.Linear(hidden_size,out_features=output_size) # final layer for lstm
            self.log_softmax = torch.nn.LogSoftmax(dim=2) 

        if self.feature_type == 'rasta':
            self.embedding_layer = torch.nn.Linear(9,input_size) # to convert the embedding into the feature vector
            self.lstm = torch.nn.LSTM(input_size=input_size,hidden_size=hidden_size
            ,num_layers=num_layers,bidirectional=bi_direct,batch_first=True) # batch_first true -> as my input is batch x sequence x feats_size
            self.dropout = torch.nn.Dropout(drop_prob) # define the dropout prob
            # dropout=drop_prob
            if bi_direct:
                self.final_layer = torch.nn.Linear(hidden_size*2,out_features=output_size)  # final layer projection for bilstm as it require 2*hidden size
            else:
                self.final_layer = torch.nn.Linear(hidden_size,out_features=output_size) # final layer for lstm
            self.log_softmax = torch.nn.LogSoftmax(dim=2) 

    def forward(self, batch_features):
        """
        :param batch_features: batched acoustic features
        :return: the output of your model (e.g., log probability)
        """
        if self.feature_type=='discrete':
            x = (self.embedding_layer(batch_features.int())) # convert the features to embeddings [batch x time x embdding_dim] -> [batch x time x input_dim]
            x = self.dropout(x) # apply dropout for regularisation
            x,_ = (self.lstm(x)) # [batch x time x input_dim] -> [batch x time x hidden_dim]
            x = self.dropout(x) # dropout
            x = self.log_softmax(self.final_layer(x)) # [batch x time x hidden_dim] -> [batch x time x out_dim]
        if self.feature_type=='mfcc' or self.feature_type == 'mfcc_delta':
            x,_ = (self.lstm(batch_features)) # [batch x time x input_dim] -> [batch x time x hidden_dim]
            x = self.dropout(x) # dropout
            x = self.log_softmax(self.final_layer(x)) # [batch x time x hidden_dim] -> [batch x time x out_dim]
        if self.feature_type=='rasta':
            x = (self.embedding_layer(batch_features.float())) # convert the features to embeddings [batch x time x embdding_dim] -> [batch x time x input_dim]
            x = self.dropout(x) # apply dropout for regularisation
            x,_ = (self.lstm(x)) # [batch x time x input_dim] -> [batch x time x hidden_dim]
            x = self.dropout(x)  # dropout
            x = self.log_softmax(self.final_layer(x)) # [batch x time x hidden_dim] -> [batch x time x out_dim]
        return x

