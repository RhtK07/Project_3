"""
Aim: In this block, dataloader for the code is written
"""
import string
import torch
import librosa
import os
import pandas as pd
from torch.utils.data import Dataset
from pdb import set_trace as bp
import numpy as np
from rasta import *
from sklearn.model_selection import train_test_split


# shared by ta
def read_file_line_by_line(file_name, func=lambda x: x, skip_header=True):
    print("reading file: %s" % file_name)
    res = list()
    with open(file_name, "r") as fin:
        if skip_header:
            fin.readline()  # skip the header
        for line in fin:
            if len(line.strip()) == 0:
                continue
            fields = func(line.strip())
            res.append(fields)
    print("%d lines, done" % len(res))
    return res

class AsrDataset(Dataset):
    def __init__(self, scr_file, feature_type='discrete', feature_file=None,
                 feature_label_file=None,
                 wav_scp=None, wav_dir=None):
        """
        :param scr_file: clsp.trnscr
        :param feature_type: "quantized" or "mfcc"
        :param feature_file: clsp.trainlbls or clsp.devlbls
        :param feature_label_file: clsp.lblnames
        :param wav_scp: clsp.trnwav or clsp.devwav
        :param wav_dir: wavforms/
        """
        self.feature_type = feature_type
        assert self.feature_type in ['discrete', 'mfcc','rasta','mfcc_delta'] # which feature you want to call
        
        self.blank = "<blank>" 
        self.silence = "<sil>"
        # 23 letters + noise
        self.letters = list(string.ascii_lowercase)
        #for c in ['k', 'q', 'z']:
        #    self.letters.remove(c)
        # since all the alphabtes are considered in the output symbol thats why lets assign for them all
        self.letters.insert(0,self.silence) # adding <sil> in the vocab        
        self.letters.insert(0,self.blank) # adding <blank> in the vocab
        self.letter2id = dict({c: i for i, c in enumerate(self.letters)}) # type: {}, given the [letter:corresponding_id]
        self.id2letter = dict({i: c for c, i in self.letter2id.items()}) # type: {}, given the [id:letter]

        # === write your code here ===
        self.trnscr = read_file_line_by_line(scr_file) # read the transcript file
        self.featslbls = read_file_line_by_line(feature_file, func=lambda x: x.split()) # read discrete features
        self.lblnames = read_file_line_by_line(feature_label_file) # unique discrete feature -> 256 unique discrete features

        self.wav_scp = wav_scp # reading wav_scp file
        self.wav_dir = wav_dir # getting the dir
        
        # 256 quantized feature-vector labels
        self.label2id = dict({lbl: i+1 for i, lbl in enumerate(self.lblnames)}) # type: {} -> assigning every discrete 256 features a unique number
        self.id2label = dict({i: lbl for lbl, i in self.label2id.items()}) # type: {} -> given the id of each label - corresponding letter
        self.featslbls = [[self.label2id[lbl] for lbl in line] for line in self.featslbls] # converting every feature into a unique intergete

        # === converting features id to feature vector ===
        #self.feature = self.featslbls
        if self.feature_type=='discrete':
            # if discrete convert to one hot emndedding
            self.feature = self.featslbls # if discrete
        if self.feature_type=='mfcc':
            # if mfcc convert to mfcc vector
            self.feature = self.compute_mfcc(self.wav_scp,self.wav_dir) # if mfcc
        if self.feature_type=='mfcc_delta':
            # if mfcc convert to mfcc vector
            self.feature = self.compute_mfcc_delta(self.wav_scp,self.wav_dir) # if mfcc + mfcc delta + mfcc double delta
        if self.feature_type=='rasta':
            # if rasta feature
            self.feature = self.compute_raasta(self.wav_scp,self.wav_dir)

        self.trnscr = [[self.letter2id[c] for c in word] for word in self.trnscr] # every word ['c','a','t'] -> [3,1,23]
        self.transcr = self.append_silence() # append <sil> in vector [<sil>,'c','a','t',<t>]

    def __len__(self):
        """
        :return: num_of_samples
        """
        return len(self.featslbls)

    def __getitem__(self, idx):
        """
        Get one sample each time. Do not forget the leading- and trailing-silence.
        :param idx: index of sample
        :return: spelling_of_word, feature
        """
        # === write your code here ===
        if self.feature_type == 'mfcc':
            feature = torch.tensor(self.feature[idx]) #call the feature label
        else:
            feature = torch.from_numpy(np.array(self.feature[idx])) #call the feature label
        label = torch.tensor(self.trnscr[idx],dtype=int) #cal the output label
        return label,feature
    
    def one_hot(self,a, num_classes):
        return np.squeeze(np.eye(num_classes)[a.reshape(-1)])
    
    def append_silence(self):
        appended_list = []
        for x in self.trnscr:
            x.insert(0,self.letter2id[self.silence]) #in start silence
            x.append(self.letter2id[self.silence]) #in end silence
        return appended_list

    # This function is provided
    def compute_mfcc(self, wav_scp, wav_dir):
        """
        Compute MFCC acoustic features (dim=40) for each wav file.
        :param wav_scp:
        :param wav_dir:
        :return: features: List[np.ndarray, ...]
        """
        features = []
        with open(wav_scp, 'r') as f:
            for wavfile in f:
                wavfile = wavfile.strip()
                if wavfile == 'jhucsp.trnwav' or wavfile == 'jhucsp.devwav':  # skip header
                    continue
                wav, sr = librosa.load(os.path.join(wav_dir, wavfile), sr=None)
                feats = librosa.feature.mfcc(y=wav, sr=16e3, n_mfcc=13, hop_length=160, win_length=400).transpose()
                features.append(feats) # use the delta and double delta features
        return features
    
    def compute_mfcc_delta(self, wav_scp, wav_dir):
        """
        Compute MFCC acoustic features (dim=40) for each wav file.
        :param wav_scp:
        :param wav_dir:
        :return: features: List[np.ndarray, ...]
        """
        features = []
        with open(wav_scp, 'r') as f:
            for wavfile in f:
                wavfile = wavfile.strip()
                if wavfile == 'jhucsp.trnwav' or wavfile == 'jhucsp.devwav':  # skip header
                    continue
                wav, sr = librosa.load(os.path.join(wav_dir, wavfile), sr=None)
                feats = librosa.feature.mfcc(y=wav, sr=16e3, n_mfcc=13, hop_length=160, win_length=400).transpose()
                feat_delta = librosa.feature.delta(feats) # cal the delta and double delta features
                feat_ddelta = librosa.feature.delta(feats,order=2)
                feat_cat = np.hstack([feats,feat_delta,feat_ddelta])
                features.append(feat_cat) # use the delta and double delta features
        return features
    
    def compute_raasta(self, wav_scp, wav_dir):
        """
        Compute PLP acoustic features (dim=9) for each wav file.
        :param wav_scp:
        :param wav_dir:
        :return: features: List[np.ndarray, ...]
        """
        features = []
        with open(wav_scp, 'r') as f:
            for wavfile in f:
                wavfile = wavfile.strip()
                if wavfile == 'jhucsp.trnwav' or wavfile == 'jhucsp.devwav':  # skip header
                    continue
                wav, sr = librosa.load(os.path.join(wav_dir, wavfile), sr=None) # load the audio file
                feats = rastaplp(wav, fs = sr, win_time = 0.040, hop_time = 0.020, dorasta = True, modelorder = 8).transpose() # cal the plp raasta feature
                features.append(feats) # append the feats
        return features

