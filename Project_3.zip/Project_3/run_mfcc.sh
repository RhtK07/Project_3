#!/bin/bash
# Date: 12th May, 2022
# Project 3

# choose between the three
feature_type="mfcc"  # discrete, mfcc, mfcc_delta, rasta

# define the max iteration to train
max_iter=150

# patience
patience=5

# training transcript
trnscr="data/clsp.trnscr"

# training discrete features
trnlbls="data/clsp.trnlbls"

# unique discrete feature
lblnames="data/clsp.lblnames"

# training wav.scp
tr_wav_scp="data/clsp.trnwav"

# training wav dir
wav_dir="data/waveforms/"

# dev discrete feature file
devlbls="data/clsp.devlbls"

# dev wav.scp
dev_wav_scp="data/clsp.devwav"

python main.py $feature_type $trnscr $trnlbls $lblnames $tr_wav_scp $wav_dir $devlbls $dev_wav_scp $max_iter $patience
